# IOT-BASED-SMART-TRAFFIC-LIGHT-MANAGEMENT-SYSTEM.-
 we will be going to accomplish this project by using Python Networking, BLOB, Haar-Cascade, OpenCV, Raspberry Pi
